/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package v2;

/**
 *
 * @author ragasi761
 */
import modelo.Alumno;

import java.sql.Date;

public class Main {

    public static void main(String[] args) {

        AlumnoDAOv2 dao = new AlumnoDAOv2();

        Alumno a1 = new Alumno(
                13,
                "Pedro Perez",
                Date.valueOf("2008-01-15"),
                7.5,
                "1A"
        );

        dao.create(a1);

        System.out.println(dao.read(13));

        a1.setMedia(9.0);
        dao.update(a1);

        dao.delete(13);

        dao.desconectar();
    }
}
