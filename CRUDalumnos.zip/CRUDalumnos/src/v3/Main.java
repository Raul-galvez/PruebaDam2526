/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package v3;

import modelo.Alumno;

import java.sql.*;

public class Main {

    private static final String URL = "jdbc:oracle:thin:@//localhost:1521/XEPDB_M";
    private static final String USER = "alumno";
    private static final String PASS = "alum2526";

    public static void main(String[] args) {

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {

            AlumnoDAOv3 dao = new AlumnoDAOv3(con);

            Alumno a1 = new Alumno(
                    14,
                    "Maria Mesa",
                    Date.valueOf("2007-04-12"),
                    8.8,
                    "2B"
            );

            dao.create(a1);

            System.out.println(dao.read(14));

            dao.update(a1);
            dao.delete(14);

        } catch (SQLException ex) {
            System.out.println("Error conexi�n: " + ex);
        }
    }
}
