/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package v3;

import modelo.Alumno;

import java.sql.*;

public class AlumnoDAOv3 {

    private Connection con;

    public AlumnoDAOv3(Connection con) {
        this.con = con;
    }

    public void create(Alumno a) {

        String sql = "INSERT INTO Alumnos2526 VALUES (?,?,?,?,?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, a.getNum());
            ps.setString(2, a.getNombre());
            ps.setDate(3, a.getFnac());
            ps.setDouble(4, a.getMedia());
            ps.setString(5, a.getCurso());

            ps.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Error insert: " + ex);
        }
    }

    public Alumno read(int id) {

        String sql = "SELECT * FROM Alumnos2526 WHERE num=?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return new Alumno(
                            rs.getInt("num"),
                            rs.getString("nombre"),
                            rs.getDate("fnac"),
                            rs.getDouble("media"),
                            rs.getString("curso")
                    );
                }
            }

        } catch (SQLException ex) {
            System.out.println("Error read: " + ex);
        }

        return null;
    }

    public boolean exists(int id) {
        return read(id) != null;
    }

    public void update(Alumno a) {

        if (!exists(a.getNum())) return;

        String sql = "UPDATE Alumnos2526 SET nombre=?, fnac=?, media=?, curso=? WHERE num=?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, a.getNombre());
            ps.setDate(2, a.getFnac());
            ps.setDouble(3, a.getMedia());
            ps.setString(4, a.getCurso());
            ps.setInt(5, a.getNum());

            ps.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Error update: " + ex);
        }
    }

    public void delete(int id) {

        if (!exists(id)) return;

        String sql = "DELETE FROM Alumnos2526 WHERE num=?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Error delete: " + ex);
        }
    }
}
