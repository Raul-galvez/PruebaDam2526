/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Date;

public class Alumno {

    private int num;
    private String nombre;
    private Date fnac;
    private double media;
    private String curso;

    public Alumno(){}

    public Alumno(int num, String nombre, Date fnac, double media, String curso){
        this.num=num;
        setNombre(nombre);
        this.fnac=fnac;
        this.media=media;
        setCurso(curso);
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.length()>30)
            this.nombre= nombre.substring(0,30);
        else
            this.nombre=nombre;
    }

    public Date getFnac() {
        return fnac;
    }

    public void setFnac(Date fnac) {
        this.fnac = fnac;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {

        if(curso.length()>2)
            this.curso= curso.substring(0,2);
        else
            this.curso=curso;
    }
    @Override
    public String toString() {

        return num+
                " "+
                nombre+
                " "+
                fnac+
                " "+
                media+
                " "+
                curso;
    }
}
