/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package v1;

import modelo.Alumno;
import java.sql.Date;

public class Main {

    public static void main(String[] args) {

        Alumno a = new Alumno(
                13,
                "Pedro Perez",
                Date.valueOf("2008-01-15"),
                7.5,
                "1A"
        );

        AlumnoDAO.create(a);

        System.out.println(AlumnoDAO.read(13));

        a.setMedia(9.2);
        AlumnoDAO.update(a);

        AlumnoDAO.delete(13);
    }
}
